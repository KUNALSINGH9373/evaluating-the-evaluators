# NeurIPS 2026 paper package

Upload these items to Overleaf while preserving the folder structure:

- `paper.tex` (set this as the main document)
- `references.bib` (editable reference metadata; the submission-ready entries are embedded in `paper.tex`)
- `neurips_2026.sty`
- the complete `figures/` folder
- `DATASET_CARD.md`
- `LICENSE.md`
- `SOURCE_USE_AND_LICENSING.md`
- `severity_prompt.txt`
- `severity_prompt_v1.0_FROZEN.txt`

The current PDF was compiled from `paper.tex` with the official 2026 style in
author-visible preprint mode. The main paper is nine pages, with the conclusion
ending on page 9. References begin on page 10, the focused appendix ends on page
23. This workshop version does not include the NeurIPS paper checklist.

If the venue requires an anonymous review copy, change the style option in
`paper.tex` from `preprint` to `main`; the current preprint copy intentionally
displays the author names.
