# Source Use and Licensing

The dataset records public evaluation findings and preserves the named source institution and public URL for every included finding. It does not redistribute source report files or model weights.

Short excerpts are retained only where needed for research, verification, criticism, and finding-level provenance. Copyright and license terms for those excerpts remain with the original rightsholders. The authors' CC BY 4.0 license covers only original annotations, documentation, and figures; the MIT terms cover only original analysis code.

The source corpus spans materials with heterogeneous terms, including publications with explicit open licenses, government publications subject to jurisdiction-specific reuse terms, and company materials without an explicit reusable-content license. A source-by-source license audit has not yet been completed. Accordingly, users who reproduce or redistribute third-party text should inspect the linked source's current terms rather than assume that the authors' licenses apply.
