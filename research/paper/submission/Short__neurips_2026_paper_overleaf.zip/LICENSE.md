# License

## Original dataset annotations, documentation, and figures

Copyright (c) 2026 the paper authors. Licensed under Creative Commons Attribution 4.0 International (CC BY 4.0): https://creativecommons.org/licenses/by/4.0/

## Original analysis code

Copyright (c) 2026 the paper authors. Permission is hereby granted, free of charge, to any person obtaining a copy of the original analysis code and associated software documentation files, to deal in the Software without restriction, including the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies, subject to inclusion of this copyright and permission notice. The Software is provided "AS IS", without warranty of any kind, express or implied.

## Exclusions

These licenses do not apply to third-party report text, quotations, trademarks, linked materials, or other content owned by source organisations. Such material remains subject to the original rightsholder's terms. See `SOURCE_USE_AND_LICENSING.md`.
