# Dataset Card: Evaluating the Evaluators

## Summary

The release contains 1,169 finding-level rows across 39 fields, derived from 484 unique public reports after screening 6,684 publication records from 46 organisations. Stable Finding and Report identifiers preserve provenance to the source institution and public URL.

## Contents and fields

Core fields cover source institution, URL, publication date, report and finding identifiers, tier, severity, access type, response-channel evidence, Action Level, Policy Level, and the derived proportionality outcome. Joint reports can have separate reporting-institution labels; this yields 47 finding-level labels from the 46-organisation screening frame.

## Collection and annotation

Eligible inputs are public evaluation reports and related public primary sources. Authors extracted findings and searched the response channels. Severity used three zero-shot model calls per finding against a fixed, versioned prompt, followed by human review of every row; the human-reviewed label is final. The corpus cutoff is August 29, 2026.

## Intended uses

- Reproduce the paper's reported quantities and figures.
- Audit finding-level provenance and coding.
- Study public follow-up to frontier-AI evaluations.
- Develop proposals for response, remediation, verification, and tracking processes.

## Out-of-scope uses

The dataset should not be used as a ranking of company safety, as evidence of unobserved private conduct, or as a complete inventory of worldwide evaluation activity. Descriptive subgroup rates can reflect evaluation volume, access, model mix, disclosure practices, and small denominators.

## People and privacy

The dataset was compiled from public organisational materials. It contains no recruited participants or private personal data.

## Documentation

See Appendix L of the paper, `SOURCE_USE_AND_LICENSING.md`, `LICENSE.md`, and the two versioned severity-prompt files. Project materials are available at https://kunalssingh.com/evaluating-the-evaluators/#data.
